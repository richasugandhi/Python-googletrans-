from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.shortcuts import render
from flask import Flask
from flask import request, redirect
from googletrans import Translator
# Create your views here.

def home(request):
    destination_languages = {
        'english': 'en',
        'afrikaans': 'af',
        'albanian': 'sq',
        'amharic': 'am',
        'arabic': 'ar',
    }
    translator = Translator()

    if request.method == 'POST':
        text = request.POST.get('searchbox','')
    else:
        text = 'How to convert some text to multiple languages'

    transtext = []
    for key, value in destination_languages.items():
        transtext.append(translator.translate(text, dest=value).text)

        ## return HttpResponse('it is working now')
    return render(request, 'index.html', {'transtext':transtext, 'len':len(transtext)})